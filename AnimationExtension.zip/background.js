let isEnabled;


chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.get(['isEnabled'], function(result) {
        isEnabled = result.isEnabled !== undefined ? result.isEnabled : true; // 저장된 값 또는 기본값 사용
        console.log("Background service worker initialized. isEnabled: ", isEnabled);
    });
});


// 상태 변경 시 저장하기
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log("Message received in background.js: ", message); // 메시지 로그

    if (message.action === 'enable') {
        isEnabled = true;
        console.log("Extension enabled");
        chrome.storage.local.set({
            'isEnabled': true
        });
    } else if (message.action === 'disable') {
        isEnabled = false;
        console.log("Extension disabled");
        chrome.storage.local.set({
            'isEnabled': false
        });
    }

    // getStatus 요청에 응답
    if (message.action === 'getStatus') {
        console.log("Sending isEnabled status: ", isEnabled); // 응답 로그
        sendResponse({
            isEnabled: isEnabled
        });
    }
});