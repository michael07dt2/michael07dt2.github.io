console.log("Resizing Extension loaded.");

// 삭제할 클래스 목록
const classesToRemove = [
    "adsbygoogle",
    "adsbygoogle-noablate"
];


// Class 제거
classesToRemove.forEach(className => {
    const elementsToRemove  = document.querySelectorAll(`.${className}`);
    elementsToRemove.forEach(element => {
        element.remove();
    });
});


// chrome.storage.local에서 isEnabled 상태를 가져오기
chrome.storage.local.get(['isEnabled'], function(result) {
    const isEnabled = result.isEnabled !== undefined ? result.isEnabled : true; // 기본값 true
    console.log("isEnabled 상태:", isEnabled); // 상태 로그 확인
    updateLayout(isEnabled); // 초기 상태에 맞게 레이아웃 적용
});


// layout을 적용하는 함수

function updateLayout(isEnabled) {
    if (true) {
        //window.location.hostname === "kr.linkkf.net"
        // 활성화/비활성화 상태에 따라 적용할 max-width 값을 변수에 저장합니다.
        const bodyMaxWidth = isEnabled ? '1440px' : '720px'; // body는 'none' 또는 '720px'
        const containerMaxWidth = isEnabled ? 'none' : '1200px';
        // '.container' 클래스를 가진 모든 요소를 한 번에 쿼리합니다.
        const containers = document.querySelectorAll('.container');
        containers.forEach(container => {
            // 각 요소에 대해 변수에 저장된 값을 적용합니다.
            container.style.maxWidth = containerMaxWidth;
            container.style.width = 'auto';
            console.log(`Container set ${container}`);
        });

        // document.body의 max-width를 업데이트합니다.
        document.body.style.setProperty('max-width', bodyMaxWidth, 'important');
        document.body.style.setProperty('margin', 'auto', 'important');
    } else {
        // kr.linkkf.net이 아닌 경우, 리사이징 관련 로직은 실행하지 않음
        console.log("Not kr.linkkf.net, resizing function will not be applied.");
    }
}
