document.addEventListener('DOMContentLoaded', function() {
    const toggleSwitch = document.getElementById('toggleSwitch');

    // chrome.storage.local에서 isEnabled 값 가져오기
    chrome.storage.local.get(['isEnabled'], function(result) {
        const isEnabled = result.isEnabled !== undefined ? result.isEnabled : true;

        // 토글 상태 설정
        toggleSwitch.checked = isEnabled;

        // 버튼 색상 변경
        updateButtonColor(toggleSwitch.checked);

        // 토글 상태가 바뀔 때마다 처리
        toggleSwitch.addEventListener('change', function() {
            const isChecked = toggleSwitch.checked;
            chrome.runtime.sendMessage({
                action: isChecked ? 'enable' : 'disable'
            });
            updateButtonColor(isChecked); // 버튼 색상 변경
            chrome.storage.local.set({
                'isEnabled': isChecked
            });

            // 토글 상태가 바뀐 후 즉시 content.js에서 상태 반영
            chrome.tabs.query({
                active: true,
                currentWindow: true
            }, function(tabs) {
                chrome.scripting.executeScript({
                    target: {
                        tabId: tabs[0].id
                    },
                    func: updateLayout,
                    args: [isChecked]
                });
            });
        });
    });
});

// 버튼 색상 업데이트
function updateButtonColor(isChecked) {
    const button = document.getElementById('toggleSwitch');
    button.style.backgroundColor = isChecked ? 'green' : 'red'; // 켜짐/꺼짐 상태에 따른 색상 변경
}

// content.js에서 페이지 레이아웃을 업데이트하는 함수
function updateLayout(isEnabled) {
    // '.container'와 '.container2' 클래스가 있는 모든 요소에 대해 처리
    const containers = document.querySelectorAll('.container, .container2');
    containers.forEach(container => {
        if (isEnabled) {
            container.style.maxWidth = 'none'; // 활성화된 상태
        } else {
            container.style.maxWidth = '1200px'; // 비활성화된 상태
        }
    });

    // document.body의 max-width를 업데이트
    if (isEnabled) {
        document.body.style.setProperty('max-width', 'none', 'important'); // 활성화된 상태
    } else {
        document.body.style.setProperty('max-width', '720px', 'important'); // 비활성화된 상태
    }
}